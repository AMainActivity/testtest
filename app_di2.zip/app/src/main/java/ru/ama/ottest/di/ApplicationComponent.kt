package ru.ama.ottest.di

import dagger.Component

//@ApplicationScope
@Component(modules = [DomainModule::class, ContextModule::class])
interface ApplicationComponent {

    fun inject(fragment: GameFragment)
	
	 @Component.Factory
    interface ApplicationComponentFactory {

        fun create(
            @BindsInstance context: Context
        ): ApplicationComponent
    }
}
