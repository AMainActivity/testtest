package ru.ama.ottest.di

import dagger.Binds
import dagger.Module

@Module
interface DomainModule {

    @Binds
    fun bindRepository(impl: GameRepositoryImpl): GameRepository
}
