package ru.ama.ottest.di

import dagger.Component

@Component(modules = [DomainModule::class, ContextModule::class])
interface ApplicationComponent {

    fun inject(fragment: GameFragment)
}
